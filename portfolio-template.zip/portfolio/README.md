# Video Editor Portfolio — Starter Template

A static, no-build-step portfolio site. Just edit the text/images and deploy.

## Files
- `index.html` — all page content and structure
- `style.css` — all styling (dark theme, purple accents)
- `script.js` — small interactions (footer year, thumbnail clicks)

## 1. Customize your content
Open `index.html` in any text editor and replace:

- **Your Name** — appears in the `<h1>`, avatar alt text, footer, and `<title>`
- **Role/tagline** — the `.role` paragraph
- **Bio** — the `.bio` paragraph
- **Instagram link** — both `href="https://instagram.com/yourhandle"` links (search and replace `yourhandle`)
- **Badges** (Precision Cuts, Cinematic Color, Clean Audio, Retention First) — swap text/emoji for your own skills
- **Services list** — inside `.services-columns`
- **Portfolio categories & thumbnails** — each `.category` block. Replace the `background-image:url('...')` on each `.thumb` div with your own image (or a video poster frame). To link a thumbnail to an actual video, wrap it in an `<a href="your-video-url">` tag or edit `script.js` to open a lightbox/YouTube embed.
- **Avatar photo** — replace the `src` on `.avatar` with your own photo (e.g. `images/me.jpg` after adding it to the `images/` folder)

## 2. Add real images
Put your thumbnail images and profile photo into the `images/` folder, then update the paths in `index.html`, e.g.:
```html
<div class="thumb thumb-h" style="background-image:url('images/talking-head-1.jpg')">
```

## 3. Preview locally
Just double-click `index.html` to open it in your browser — no server or build tools needed.

## 4. Deploy to Vercel
**Option A — Drag and drop (easiest):**
1. Go to https://vercel.com/new
2. Drag this whole folder onto the page
3. Click Deploy — you'll get a live `yourproject.vercel.app` URL in seconds

**Option B — Via GitHub (recommended for future edits):**
1. Create a new GitHub repo and push these files
2. Go to https://vercel.com/new, import the repo
3. Leave all build settings blank/default (it's a static site — no framework, no build command)
4. Click Deploy

## 5. Custom domain (optional)
In your Vercel project settings → Domains → add your own domain (e.g. `yourname.com`) and follow the DNS instructions.

## Notes
- Thumbnail images currently use placeholder photos from picsum.photos — replace these with your real work before publishing.
- The avatar uses a placeholder generated initials icon — replace with your real photo.
- Fully responsive down to mobile; side badges hide on small screens to avoid clutter.
