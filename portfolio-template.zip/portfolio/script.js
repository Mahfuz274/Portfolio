// Auto-update footer year
document.getElementById('year').textContent = new Date().getFullYear();

// Placeholder click behavior for thumbnails — replace with real video links/lightbox later
document.querySelectorAll('.thumb').forEach(function (thumb) {
  thumb.addEventListener('click', function () {
    alert('Add your video link or lightbox here. Edit script.js to wire this up.');
  });
});
